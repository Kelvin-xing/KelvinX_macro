EAES_RA09 replication

+ last change: 2011-08-25

replication: IRF to a spanish technology shock in the tradable sector 
	     IRF to a spanish demand shock in the non-tradable sector

+ replicated IRFs: EAES_RA09_irf

+ file to produce replicated IRFs: run.m (which calls EAES_RA09_rep.mod in the folder EAES_RA09_rep)

+ original IRFs: Figure 5 on page 1163 in Rabanal (2009)

+ literature:
  - Rabanal, Pau (2009): "Inflation Differentials between Spain and the EMU: A DSGE Perspective," Journal of Money, Credit and Banking 41(6).

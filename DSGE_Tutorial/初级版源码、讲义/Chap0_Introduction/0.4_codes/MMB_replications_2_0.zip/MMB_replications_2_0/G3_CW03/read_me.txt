G3_CW03 Replication

+ last change: 2009-01-21

+ replication: IRF to demand shock (0.5 percentage points) 

+ replicated IRF: G3_CW03_irf.pdf

+ file to produce replicated IRF: run.m (which calls G3_CW03_rep.mod in the folder G3_CW03_rep)

+ original IRF: figure 3 in the paper (page 28)

+ literature:
  - Coenen and Wieland, Inflation Dynamics and International Linkages: A Model of the United States, the Euro Area and Japan, ECB Working paper No. 181
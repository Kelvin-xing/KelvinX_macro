EACZ_GEM03 Replication

+ last change: 2009-01-07

+ replication: standard deviation of selected variables

+ file with the comparisson of results: EA_GEM03_rep_results.xls 

+ original results: 2nd row of Table 4 in Laxton & Pesenti (2003)

+ file to produce replicated standard deviation: EACZ_GEM03_rep.mod in folder EACZ_GEM03_rep

+ literature:
  - Laxton and Pesenti, Monetary rules for small, open, emerging economies, Journal of Monetary Economics, 2003, 50


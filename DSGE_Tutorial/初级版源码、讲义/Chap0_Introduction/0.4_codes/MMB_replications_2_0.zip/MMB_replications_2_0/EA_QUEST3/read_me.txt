EA_QUEST3 Replication

+ last change: 2009-01-09

+ replication: IRF to monetary shock (one standard deviation) 

+ replicated IRF: EA_QUEST3_irf.pdf

+ file to produce replicated IRF: run.m (which calls EA_QUEST3_rep.mod in the folder EA_QUEST3_rep)

+ original IRF: figure 2 on page 9 in Ratto et al. 2008

+ literature:
  - Ratto, Roeger, in �t Veld, QUEST III: An Estimated Open-Economy DSGE Model of the Euro Area with Fiscal and         Monetary Policy, Economic Modelling, 2009
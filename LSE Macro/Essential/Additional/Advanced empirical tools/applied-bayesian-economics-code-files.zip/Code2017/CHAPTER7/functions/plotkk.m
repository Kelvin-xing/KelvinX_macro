function [ h ] = plotkk( t,x )
h=plot(t,x,'-k','LineWidth',0.5);

end


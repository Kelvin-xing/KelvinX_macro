function [ h ] = plotk2( t,x )
h=plot(t,x(:,1),'c','LineWidth',2);
% hold on
% h=plot(t,x(:,2),'.c','LineWidth',0.5);
% hold on
% h=plot(t,x(:,3),'.c','LineWidth',0.5);
end


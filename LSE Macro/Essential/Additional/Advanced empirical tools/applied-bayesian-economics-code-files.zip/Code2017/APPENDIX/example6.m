clear

REPS=100; % number of repetitions
Z=zeros(REPS,1);
for i=1:REPS
    Z(i,1)=i^2;
end


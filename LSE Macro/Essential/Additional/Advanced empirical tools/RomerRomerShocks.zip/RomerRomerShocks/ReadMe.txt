Replication codes for the monetary shocks by Romer and Romer (2004), "A new measure of 
monetary shocks: derivation and implications", American Economic Review, Vol 94(4). 

Michele Piffer, m.b.piffer@gmail.com


DESCRIPTION
The codes in this file replicate computation of the Romer and Romer shocks and compute
pseudo shocks required to address the generated regressor problem. To do so, I extend the
Monte Carlo methodology that they use in equation 2 to equation 1 of the paper


LIST OF FILES
- ReplicationRomerRomer_1969_1996.m - Matlab code replicating the computation of the Romer 
				and Romer shocks using their original data. They are computed
				as the residuals of regression 1. Pseudo shocks are then 
				computed using Monte Carlo, by extracting from a multivariate
				normal with mean and variance equal to the point estimates and 
				variance obtained in the regression 1 and by then computing the 
				pseudo residuals. The generated original and pseudo shocks cover	
				the period between 1969M1 and 1996M12. The shocks saved in the 
				file below cover until June 2007. Impulse responses
				are computed accounting for the generated regressor problem and
				giving a comparison between considering and not considering the 
				generated regressor problem


- zFC_IRF_RRsingleequation.m - Matlab code computing impulse responses, given parameter estimates
				of the single equation model used in the paper (equation 2)

- RomerandRomerDataAppedix.xls - Data from the original paper

- DatasetDescription.pdf 

- SHOCKS_RomerRomer_1996_2007.mat - Matlab file containing data on shocks replicated until June 
				2007 using data collected by Coibion, Gorodnichenko, Kueng, Silvia 
				(2012) "Innocent bystanders? Monetary policy and inequality in the 
				US". The file contains monthly and quarterly series, the latter being
				computed as the sum within quarter. For each of these, it contains
				a vector of the time axis covered and 1000 pseudo shocks computed 
				as explained above



The codes and the pseudo monetary shocks computed can be used freely. Please let me know 
if you find typos or errors




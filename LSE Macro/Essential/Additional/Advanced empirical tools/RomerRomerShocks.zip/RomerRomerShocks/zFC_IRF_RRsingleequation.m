function IRF = zFC_IRF_RRsingleequation(beta_used,lags_shocks,T_irf,lags_depvariab,shock_given)

%==========================================================================
% Computes impulse response function using the approach by Romer and Romer 
% (2004) 

% Michele Piffer, m.b.piffer@gmail.com
% October 2014, DIW Berlin

% INPUT
% beta_used = regression estimates from the singe equation model.
%             First enter the monetary shocks, then lagged dependent
%             variable, then other possible controls
% lags_shocks = number of lags of the shocks included in addition to the 
%             constant
% T_irf = periods for which to compute the impulse responses
% lags_depvariab = number of lags of the dependent variable
% shock_given = size and sign of the monetary shock given

% OUTPUT
% IRF = vector of impulse response generated
%==========================================================================


alphas = [beta_used(1:lags_shocks+1); zeros(T_irf-lags_shocks-1,1)]; % coefficients on shocks
betas = beta_used(lags_shocks+1+1:lags_shocks+1+lags_depvariab);     % coefficients on lagged dependent variable

IRF_diff = NaN*ones(T_irf,1);
IRF_diff_step = [zeros(lags_depvariab,1); NaN*ones(T_irf,1)];
for i = 1:T_irf
  IRF_diff(i) = alphas(i)*shock_given + betas'*flipud(IRF_diff_step(i:i+lags_depvariab-1));
  IRF_diff_step(lags_depvariab+i) = IRF_diff(i);
end

% compute cumulated IRF
IRF = NaN*ones(T_irf,1);
for t = 1:T_irf
   IRF(t) = sum(IRF_diff(1:t));
end

end
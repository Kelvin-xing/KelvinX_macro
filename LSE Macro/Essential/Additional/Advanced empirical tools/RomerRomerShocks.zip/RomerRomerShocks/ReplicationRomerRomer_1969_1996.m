%==========================================================================
% Replication code for the Romer and Romer (2004) shocks and computation of
% pseudo shocks in order to account for the generated regressor problem

% Michele Piffer, m.b.piffer@gmail.com
% October 2014, DIW Berlin

%==========================================================================

clc
clear
close all


%% IMPORT MEETING DATA
MeetingData = xlsread('RomerandRomerDataAppendix.xls', 'DATA BY MEETING');
N = size(MeetingData,1);

MTGDATE	= MeetingData(:,1);
DTARG	= MeetingData(:,2); 
OLDTARG	= MeetingData(:,3);
GRADM	= MeetingData(:,4);
GRAD0	= MeetingData(:,5);
GRAD1	= MeetingData(:,6);
GRAD2	= MeetingData(:,7);
IGRDM	= MeetingData(:,8);
IGRD0	= MeetingData(:,9);
IGRD1	= MeetingData(:,10);
IGRD2	= MeetingData(:,11);
GRAYM	= MeetingData(:,12);
GRAY0	= MeetingData(:,13);
GRAY1	= MeetingData(:,14);
GRAY2	= MeetingData(:,15);
IGRYM	= MeetingData(:,16);
IGRY0	= MeetingData(:,17);
IGRY1	= MeetingData(:,18);
IGRY2	= MeetingData(:,19);
GRAU0	= MeetingData(:,20);
RESID_meetings	= MeetingData(:,21);
DFFMTG	= MeetingData(:,22);
RESIDF  = MeetingData(:,23);

clear MeetingData

%% CREATE A VARIABLE THAT KEEPS TRACK OF THE TIME
year = NaN*ones(length(MTGDATE),1);  % keeps only the year of MTGDATE
month = NaN*ones(length(MTGDATE),1); % keeps only the month of MTGDATE

for i = 1:length(MTGDATE)
    assert(numel(num2str(MTGDATE(i))) <= 6 )
    assert(numel(num2str(MTGDATE(i))) >= 5 )

    step = num2str(MTGDATE(i));
    
    year(i) = str2num(step(end-1:end)) + 1900;
    if numel(num2str(MTGDATE(i))) == 5
        month(i) = str2num(step(1));
    elseif numel(num2str(MTGDATE(i))) == 6
        month(i) = str2num(step(1:2));        
    end   
end

%% ESTIMATE THE MONETARY SHOCKS 
y = DTARG;

X = [ones(N,1), OLDTARG, ...
    GRAYM, GRAY0, GRAY1, GRAY2, ...
    IGRYM, IGRY0, IGRY1, IGRY2, ...
    GRADM, GRAD0, GRAD1, GRAD2, ...
    IGRDM, IGRD0, IGRD1, IGRD2, ...
    GRAU0];

% drop observations that have NaN in any of the variables
cond = sum(isnan(X),2);
cond2 = cond == 0;
missing = find(cond2 == 0);

y_use = y(cond2);
X_use = X(cond2,:);

% estimate the Romer and Romer regression
gamma = (X_use'*X_use)^(-1)*X_use'*y_use;
resid = y_use-X_use*gamma;
RSS = resid'*resid;

Vcov_gamma = (RSS/length(y_use))*(X_use'*X_use)^(-1); 

% add back the missing observations, for which could not estimate the residual
resid_meetings = resid;
for i = 1:length(missing)
   c = missing(i);
   resid_meetings = [resid_meetings(1:c-1); NaN; resid_meetings(c:length(resid_meetings))];
end

% figure(1)
% plot(resid_meetings, '.- b', 'Linewidth', 2), hold on % replicated ones
% plot(RESID_meetings, 'r')   % original ones
% legend('shocks replicated in this code', 'shocks from the original paper', 'Location', 'SouthWest')

%% TRANSFORM INTO MONTHLY ESTIMATES
time_monthly = [year(1) : 1/12 : year(end)+1-1/12];
resid_monthly = NaN*ones(length(time_monthly),1); % the monthly shocks (from 1969M1 to 1996M12)

for yy = min(year):max(year)
    for mm = 1:12
        cond_y = year == yy;
        cond_m = month == mm;
        resid_monthly((yy-min(year))*12 + mm) = sum(resid_meetings(cond_y.*cond_m == 1));
    end
end

resid_monthly(isnan(resid_monthly)) = 0;

%% GENERATE PSEUDO MONETARY SHOCKS, USED LATER TO COMPUTE SECOND LAYER OF UNCERTAINTY
Loops = 1000;

gamma_loop = mvnrnd(gamma,Vcov_gamma,Loops)';
resid_monthly_loop = NaN*ones(length(time_monthly),Loops);

for b = 1:Loops
   
    Loops - b
    
    % pseudo shocks, following the timeline of meetings
    resid_pseudo = y_use-X_use*gamma_loop(:,b);
   
    resid_meetings_pseudo = resid_pseudo;
    for i = 1:length(missing)
       c = missing(i);
       resid_meetings_pseudo = [resid_meetings_pseudo(1:c-1); NaN; resid_meetings_pseudo(c:length(resid_meetings_pseudo))];
    end  
    
    % transform into monthly
    resid_monthly_pseudo = NaN*ones(length(time_monthly),1);
    for yy = min(year):max(year)
        for mm = 1:12
            cond_y = year == yy;
            cond_m = month == mm;
            resid_monthly_pseudo((yy-min(year))*12 + mm) = sum(resid_meetings_pseudo(cond_y.*cond_m == 1));
        end
    end

    resid_monthly_pseudo(isnan(resid_monthly_pseudo)) = 0;    
    resid_monthly_loop(:,b) = resid_monthly_pseudo;
end

% figure(2)
% for b = 1:Loops
%     plot(time_monthly, resid_monthly_loop_show(:,b), 'y'), hold on
% end
% plot(time_monthly, resid_monthly_show), hold on
% axis([min(time_monthly) max(time_monthly) -Inf Inf])

%% IMPORT MONTHLY DATA
MonthlyData = xlsread('RomerandRomerDataAppendix.xls', 'DATA BY MONTH');

RESID_monthly = MonthlyData(:,1);
IP = MonthlyData(:,5);  % already in log change
FF = MonthlyData(:,2);  % already in fed funds rate
CPI = MonthlyData(:,8); % already in fed funds rate

clear MonthlyData

timeaxis_data = [1966 : 1/12 :  1997-1/12];
assert( length(timeaxis_data) == length(RESID_monthly) )


%% COMPUTE IRFs
from = 1970;
until = 1997-1/12;

timeaxis_used = [from : 1/12 :  until];

% Variable studied
variable_used = IP( find(timeaxis_data == from) : find(timeaxis_data == until));
% variable_used = FF( find(timeaxis_data == from) : find(timeaxis_data == until));
% variable_used = CPI( find(timeaxis_data == from) : find(timeaxis_data == until));

% Shocks used as regressors
shocks_used = resid_monthly( find(time_monthly == from):find(time_monthly == until));

% figure(4)
%     subplot(2,1,1)
% plot(timeaxis_used, variable_used, 'b', 'Linewidth', 2), hold on
% axis([from until -Inf Inf])
% title('Dependent variable')
%     subplot(2,1,2)
% plot(timeaxis_used, shocks_used, 'b', 'Linewidth', 2)
% axis([from until -Inf Inf])
% title('Shocks used')

constant = 1;
monthlydummies = 1;
shock_given = -1;

% Variables for the regression
T_irf = 48; 
lags_shocks = 36;     % number of lags included in addition to the contemporaneous one
lags_depvariab = 24;  % number of laga of the dependent variable included as regressors
T = length(timeaxis_used);

obs_lost = max(lags_shocks,lags_depvariab);

T_used = T-obs_lost;
y = variable_used(obs_lost+1:T);
timeaxis_used_smaller = timeaxis_used(obs_lost+1:T)';
assert(length(y) == length(timeaxis_used_smaller))

% Add shocks to regressors
X = shocks_used(obs_lost+1:T);
for q = 1:lags_shocks
   X = [X, shocks_used(obs_lost+1-q:T-q)]; 
end
assert(length(y) == size(X,1))

% Add lagged dependent variable to regressors
for pp = 1:lags_depvariab
    X = [X, variable_used(obs_lost+1-pp:T-pp)];
end

if constant == 1
    X = [X, ones(size(X,1),1)];
end

if monthlydummies == 1
   step1 = [eye(11); zeros(1,11)]; 
   step2 = kron(ones(ceil(size(X,1)/4),1),step1);
   step3 = step2(1:size(X,1),:);
   X = [X, step3];
end

data = [timeaxis_used_smaller, y, X];


% ESTIMATION with OLS (same also with Bayesian estimation, since use Non informative prior)
beta_ols = (X'*X)^(-1)*X'*y;
fitted = X*beta_ols;
resid = y - X*beta_ols;
RSS = resid'*resid;

Vcov_beta = (RSS/T_used)*(X'*X)^(-1); 
    
% Diagnosis of residuals
M = eye(size(X,1)) - X*(X'*X)^(-1)*X';
L = eye(size(X,1)) - ones(size(X,1),1)*ones(1,size(X,1))/size(X,1);
Rsquared = 1-(y'*M*y)/(y'*L*y)

    
% COMPUTE IMPULSE RESPONSES
beta_used = beta_ols;
IRF = zFC_IRF_RRsingleequation(beta_used,lags_shocks,T_irf,lags_depvariab,shock_given);

% figure(5)
% plot([1:1:T_irf], IRF, 'b', 'Linewidth', 2), hold on 
% plot([1:1:T_irf], zeros(T_irf,1), 'r', 'Linewidth', 1), hold on         
% axis([1 T_irf -Inf Inf]),
% set(gca,'box','off'), 
% set(gcf, 'PaperPositionMode', 'auto'); 
% xlabel('quarters', 'FontAngle','italic'),


%% CONFIDENCE INTERVALS ONLY WITH UNCERTAINTY FROM RESIDUAL

Loops = 100; 

IRF_loop = NaN*ones(T_irf,Loops);

beta_loop = mvnrnd(beta_used,Vcov_beta,Loops)';

for b = 1:Loops
    beta_usedforirf = beta_loop(:,b);
    
    IRF_pseudo = zFC_IRF_RRsingleequation(beta_usedforirf,lags_shocks,T_irf,lags_depvariab,shock_given);
    IRF_loop(:,b) = IRF_pseudo;
end

IRF_loop_95_1 = zeros(T_irf,2);
IRF_loop_68_1 = zeros(T_irf,2);
for t = 1:T_irf   
    IRF_loop_95_1(t,1) = prctile(IRF_loop(t,:),2.5);    
    IRF_loop_95_1(t,2) = prctile(IRF_loop(t,:),97.5);    
    IRF_loop_68_1(t,1) = prctile(IRF_loop(t,:),16);    
    IRF_loop_68_1(t,2) = prctile(IRF_loop(t,:),84);  
end


%% CONFIDENCE INTERVALS WITH UNCERTAINTY ALSO FROM REGRESSORS
tic

IRF_loop = NaN*ones(T_irf,Loops^2);

for b = 1:Loops
    
    Loops - b
    
    % pseudo shock used 
    shocks_used_pseudo = resid_monthly_loop( find(time_monthly == from) : find(time_monthly == until),b);

    % recompute regressors
    X_pseudo = shocks_used_pseudo(obs_lost+1:T);
    for q = 1:lags_shocks
       X_pseudo = [X_pseudo, shocks_used_pseudo(obs_lost+1-q:T-q)]; 
    end
    assert(length(y) == size(X_pseudo,1))

    % Add lagged dependent variable to regressors
    for pp = 1:lags_depvariab
        X_pseudo = [X_pseudo, variable_used(obs_lost+1-pp:T-pp)];
    end

    if constant == 1
        X_pseudo = [X_pseudo, ones(size(X,1),1)];
    end

    if monthlydummies == 1
       step1 = [eye(11); zeros(1,11)]; 
       step2 = kron(ones(ceil(size(X,1)/4),1),step1);
       step3 = step2(1:size(X,1),:);
       X_pseudo = [X_pseudo, step3];
    end

    % ESTIMATION with OLS 
    beta_ols_pseudo = (X_pseudo'*X_pseudo)^(-1)*X_pseudo'*y;
    fitted_pseudo = X_pseudo*beta_ols_pseudo;
    resid_pseudo = y - X_pseudo*beta_ols_pseudo;
    RSS_pseudo = resid_pseudo'*resid_pseudo;

    Vcov_beta_pseudo = (RSS_pseudo/T_used)*(X_pseudo'*X_pseudo)^(-1); 

    beta_loop = mvnrnd(beta_ols_pseudo,Vcov_beta_pseudo,Loops)';

    for bbb = 1:Loops
        beta_usedforirf = beta_loop(:,bbb);
        IRF_pseudo = zFC_IRF_RRsingleequation(beta_usedforirf,lags_shocks,T_irf,lags_depvariab,shock_given);
        IRF_loop(:,(b-1)*Loops + bbb) = IRF_pseudo;
    end
end

toc

IRF_loop_95 = zeros(T_irf,2);
IRF_loop_68 = zeros(T_irf,2);
for t = 1:T_irf   
    IRF_loop_95(t,1) = prctile(IRF_loop(t,:),2.5);    
    IRF_loop_95(t,2) = prctile(IRF_loop(t,:),97.5);    
    IRF_loop_68(t,1) = prctile(IRF_loop(t,:),16);    
    IRF_loop_68(t,2) = prctile(IRF_loop(t,:),84);  
end


%% COMBINED FIGURES

grey = [0.8,0.8,0.8]; 
grey2 = [0.6,0.6,0.6];


figure(2234)
    subplot(2,1,1)
fill([1:1:T_irf,fliplr(1:1:T_irf)],[IRF_loop_95_1(:,1)',fliplr(IRF_loop_95_1(:,2)')],...
         grey,'EdgeColor','none'), hold on
fill([1:1:T_irf,fliplr(1:1:T_irf)],[IRF_loop_68_1(:,1)',fliplr(IRF_loop_68_1(:,2)')],...
         grey2,'EdgeColor','none'), hold on
plot([1:1:T_irf], IRF, 'b', 'Linewidth', 2), hold on 
plot([1:1:T_irf], zeros(T_irf,1), 'r', 'Linewidth', 1), hold on         
axis([1 T_irf -Inf Inf]),
set(gca,'box','off'), 
set(gcf, 'PaperPositionMode', 'auto'); 
xlabel('months', 'FontAngle','italic')
title('ONE UNCERTAINTY')

    subplot(2,1,2)
fill([1:1:T_irf,fliplr(1:1:T_irf)],[IRF_loop_95(:,1)',fliplr(IRF_loop_95(:,2)')],...
         grey,'EdgeColor','none'), hold on
fill([1:1:T_irf,fliplr(1:1:T_irf)],[IRF_loop_68(:,1)',fliplr(IRF_loop_68(:,2)')],...
         grey2,'EdgeColor','none'), hold on
plot([1:1:T_irf], IRF, 'b', 'Linewidth', 2), hold on 
plot([1:1:T_irf], zeros(T_irf,1), 'r', 'Linewidth', 1), hold on         
axis([1 T_irf -Inf Inf]),
set(gca,'box','off'), 
set(gcf, 'PaperPositionMode', 'auto'); 
xlabel('months', 'FontAngle','italic'),
title('TWO UNCERTAINTIES')




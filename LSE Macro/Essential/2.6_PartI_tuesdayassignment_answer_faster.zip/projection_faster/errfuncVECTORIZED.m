function [ssr,error] = errfuncVECTORIZED(coef,par,grid,gh)

%Allocating memory
lhs = zeros(grid.size,1);
rhs = zeros(grid.size,1);
temp = zeros(grid.size,gh.size);
lhs = pfunc(grid.d,coef);

    for j = 1:gh.size
        %CALCULATE HERE THE RHS OF THE EULER EQUATION FOR EACH GAUSSIAN
        %HERMITE NODE.
        %temp(j,1) = ...;
        dnew = par.mud+par.rhod*grid.d+sqrt(2)*par.sigma*gh.e(j,1);
        pnew = pfunc(dnew,coef);
        qnew = par.beta*(dnew./grid.d).^-par.gamma;
        temp(:,j) = gh.w(j,1)/sqrt(pi)*qnew.*(dnew+pnew);
    end
    
    rhs   = sum(temp,2);
    error = abs(lhs-rhs);
    ssr   = norm(lhs-rhs);
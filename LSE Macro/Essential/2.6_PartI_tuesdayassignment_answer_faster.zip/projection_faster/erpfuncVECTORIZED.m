function erp = erpfuncVECTORIZED(coef,par,grid,gh,k)

%Allocating memory
p = zeros(grid.size,1);
er = zeros(grid.size,1);
rf = zeros(grid.size,1);
temp = zeros(grid.size,gh.size);

% Price
p = pfunc(grid.d,coef);

%Expected rate of return
for j = 1:gh.size
    dnew = par.mud+par.rhod*grid.d+sqrt(2)*par.sigma*gh.e(j,1);
    pnew = pfunc(dnew,coef);
    temp(:,j) = gh.w(j,1)/sqrt(pi)*(dnew+pnew);
end
er = sum(temp,2)./p-1; % Expected return


%Risk-free rate
for j = 1:gh.size
    dnew = par.mud+par.rhod*grid.d+sqrt(2)*par.sigma*gh.e(j,1);
    qnew = par.beta*(dnew./grid.d).^-par.gamma;
    temp(:,j) = gh.w(j,1)/sqrt(pi)*qnew;
end
rf = 1./(sum(temp,2))-1; % Risk free rate


if k == 1
    erp = er-rf; % Expected risk premium = expected return - risk free rate
end
if k == 2
    erp = er;
end
if k == 3
    erp = rf;
end


end
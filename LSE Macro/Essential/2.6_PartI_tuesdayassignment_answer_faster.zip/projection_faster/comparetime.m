% Compare vectorized and non vectorized

% Original file
mainORIGINAL
save timeorig wst1 eft1 rpt1
mainVECTORIZED
clc
load timeorig
x = [eft1,rpt1,wst1,eft,rpt,wst]';
% First row is the original, second is vectorized
fprintf(1, '      Error function    Risk premiun function  Whole script with no plots\n')
fprintf(1, '\t\t%2d\t\t%2d\t\t\t%2d\n', x')
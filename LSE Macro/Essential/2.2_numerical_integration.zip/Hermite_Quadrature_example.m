% Calculate E[h(x)] when x ~ N(0,sigma^2)

sigma = 1;
mean  = 0;

% Define the function
h = @(x) x.^2 + x.^4;

%kurtosis of standard Normal = 3

%get Hermite quadrature nodes and weights.
q_number = 3;
[q_nodes,q_weights]= hernodes(q_number);


t_nodes = sqrt(2)*sigma*q_nodes+mean; % transformed nodes
f_nodes = h(t_nodes);

Expectation = q_weights'*f_nodes/sqrt(pi);


disp(Expectation)
